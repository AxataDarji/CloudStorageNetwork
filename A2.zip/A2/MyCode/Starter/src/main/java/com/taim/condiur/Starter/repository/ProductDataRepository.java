package com.taim.condiur.Starter.repository;

import com.taim.condiur.Starter.domain.ProductData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductDataRepository extends JpaRepository<ProductData, Integer> {
    // You can add custom query methods here if needed
}
