package com.taim.condiur.Starter.service;

import com.taim.condiur.Starter.domain.ProductData;
import com.taim.condiur.Starter.repository.ProductDataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductDataService {

    @Autowired
    private ProductDataRepository productRepository;

    public void saveAll(List<ProductData> products) {
        productRepository.saveAll(products);
    }

    public List<ProductData> getAllProducts() {
        return productRepository.findAll();
    }
}
