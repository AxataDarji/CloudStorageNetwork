package com.taim.condiur.Starter.Controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.taim.condiur.Starter.domain.ProductData;
import com.taim.condiur.Starter.service.ProductDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/")
@Validated
public class StoreProductsController {

    @Autowired
    private Gson gson;

    @Autowired
    private ProductDataService productService;

    @RequestMapping(value = "/store-products", method = RequestMethod.POST)
    public ResponseEntity<?> storeProducts(@RequestBody String productsJsonInput) {
        System.out.println("productsJsonInput: " + productsJsonInput);
        try {
            JsonObject jsonObject = gson.fromJson(productsJsonInput, JsonObject.class);
            JsonArray productsArray = jsonObject.getAsJsonArray("products");

            if (productsArray != null) {
                List<ProductData> productDataList = new ArrayList<>();
                for (JsonElement productElement : productsArray) {
                    JsonObject productObject = productElement.getAsJsonObject();
                    String name = productObject.get("name").getAsString();
                    String price = productObject.get("price").getAsString();
                    boolean availability = productObject.get("availability").getAsBoolean();
                    ProductData productData = new ProductData();
                    productData.setName(name);
                    productData.setPrice(price);
                    productData.setAvailability(availability);
                    productDataList.add(productData);
                }
                System.out.println("productDataList: " + productDataList);
                productService.saveAll(productDataList);
                return ResponseEntity.ok("{ \"message\": \"Success.\"}");
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("No products found in the input JSON");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error in storing products: " + e.getMessage());
        }
    }

    @RequestMapping(value = "/list-products", method = RequestMethod.GET)
    public ResponseEntity<?> listProducts() {
        try {
            List<ProductData> products = productService.getAllProducts();

            JsonObject responseJson = new JsonObject();
            JsonArray productsJsonArray = new JsonArray();
            for (ProductData product : products) {
                JsonObject productJson = new JsonObject();
                productJson.addProperty("name", product.getName());
                productJson.addProperty("price", product.getPrice());
                productJson.addProperty("availability", product.isAvailability());
                productsJsonArray.add(productJson);
            }
            responseJson.add("products", productsJsonArray);

            System.out.println("productDataListResponse: " + responseJson.toString());
            return ResponseEntity.ok(responseJson.toString());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error while retrieving products: " + e.getMessage());
        }
    }
}
